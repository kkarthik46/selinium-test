package com.Employee;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmRep extends JpaRepository<Employee,Integer> {

}
