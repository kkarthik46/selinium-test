import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTest {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
    	System.setProperty("webdriver.chrome.driver","E:\\selinieum\\95\\chromedriver.exe");
    	
    	WebDriver wd=new ChromeDriver();
 
    	wd.get("http://localhost:8085/TestWebsource/index.html");
    	
    	
    	wd.manage().window().maximize();
    	
    	wd.findElement(By.name("name")).sendKeys("David");
    	wd.findElement(By.name("email")).sendKeys("da@g.co");
    	wd.findElement(By.name("submit")).submit();
    	String actualresult=wd.findElement(By.name("h1")).getText();
    	
    	String expectedname="David";
    	String expectedemail="da@g.co";
    	String expectedresult="Success";
    	
    	boolean result=false;
    	
    	Connection con=DBUtil.getConnection();
    	String sql="select * from webtest";
    	PreparedStatement ps=con.prepareStatement(sql);
    	ResultSet rs=ps.executeQuery();
    	String actualname="";
    	String actualemail="";
    	
    	while(rs.next())
    	{
    		actualname=rs.getString(1);
    		actualemail=rs.getString(2);
  
    	}
    	
    	
    	if(actualname.equals(expectedname)&&actualemail.equals(expectedemail)&&actualresult.equals(expectedresult)) {
    		result=true;
    	}
    	
    	if(result==true) {
    		System.out.println("testcase is passed");
    	}
    	else {
    		System.out.println("testcase is failed");
    	}
    	
	}

}
