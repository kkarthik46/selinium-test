package TestngExample.Testng;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Testing {
	
	@Test
	public void test1() {
		WebDriverManager.chromedriver().setup();
		WebDriver wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.google.com/");
		wd.findElement(By.name("q")).sendKeys("simplilearn",Keys.ENTER);
		String actualtitle=wd.getTitle();
		String Expectedtitle="simplilearn - Google Search";
		assertEquals(Expectedtitle,actualtitle,"titles are not matching");
		wd.quit();
		
	}
	
	

	@Test
	public void test2() {
		WebDriverManager.chromedriver().setup();
		WebDriver wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.amazon.com/");
		wd.quit();
		
	}

}
